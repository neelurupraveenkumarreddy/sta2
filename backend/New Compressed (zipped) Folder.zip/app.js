const Express = require("express")

const app = Express()

const SportRouter = require("./Routers/SportRouter")

app.use(Express.json())
app.use(Express.urlencoded({ extended: true }))

app.use("/api/sports", SportRouter)

module.exports = app