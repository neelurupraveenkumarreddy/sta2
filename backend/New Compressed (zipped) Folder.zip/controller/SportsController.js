const SportsModel = require("../Modules/Sports")
module.exports.getSports = async (req, res) => {
    const data = await SportsModel.find({})
    res.status(200).json({ success: true, data })
}

module.exports.createSports = async (req, res) => {
    const bodyData = req.body
    try {
        const sport = SportsModel(bodyData)
        await sport.save()
    } catch (err) {
        console.log(err)
        return res.status(400).json({ success: false, msg: "Falied to create." })
    }
    res.status(200).json({ success: true, msg: "Sport Creared Success" })
}