const mongoose = require("mongoose")
const sportsSchema = new mongoose.Schema({
    name: {
        type: String,
        require: true
    }
})
const sports = mongoose.model("Sports", sportsSchema)
module.exports = sports