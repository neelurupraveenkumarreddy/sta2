const Express = require("express")
const SportSController = require("../controller/SportsController")
const router = Express.Router()
router.route("/")
    .get(SportSController.getSports)
    .post(SportSController.createSports)
module.exports = router